* 
* Use this directory and files as a model to create your new plugin.
* 
* DO IT ON A TEST WEBSITE ! NOT A PRODUCTION ONE'S
*
*
* 1.
* copy the com_REPLACEnewplugin directory 
* to a new one's with your component code name  (as for example com_docman)
*
* There is 2 files. 
* For each, search all the words 'REPLACE' to find all places where you have
* somethings to change according to your target component.
*
* for example: 
* you will find :  com_REPLACEnewplugin 
* 			rename REPLACEnewplugin by your component code name 
*			example of result:  com_docman
* you will find : $row->REPLACEcatid
*			rename REPLACEcatid by the category fieldname of your component (if it exists one...)
* 
* 2.
* add call of plugin at the right place in your component files
* you have an example of instructions in the top of the file josc_com_REPLACEnewplugin.php 
* 
* 3. 
* adapt sql queries and all functions according to your component needed
* there is an explanation just before the declaration of each function
* if something is not clear, do not hesitate to contact the joomlacomment support.
*
* note: there is no difference between the call for "write comment" link
* Or for post board. It is the in the checkVisual that you will decide what
* should be displaid.
* 
* 4.
* create in the setting a new entry and select your component for this entry
* you will have to save this entry first before your section/category lists will be available.  
* 
* 5.
* check the result !
*
* If your component can use bot, you can copy joscomment bot and adapt the code. 
*
* DO NOT HESITATE TO CONTACT THE JOOMLACOMMENT FORUM (http://joomlacode.org/gf/project/joomagecomment)
* IN CASE OF QUESTIONS, PROBLEMS, OR FEATURES REQUESTS. 
* 
* Have fun with joomlacomment and long life to joomla community !
*
 